class InputFile:
    def __init__(self, path, name, file):
        self.path = path
        self.name = name
        self.file = file